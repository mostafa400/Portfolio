export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white py-12 dark:border-gray-800 dark:bg-surface-dark">
      <div className="mx-auto flex max-w-[960px] flex-col items-center gap-6 px-6 lg:px-40">
        <div className="flex items-center gap-2 text-text-main dark:text-white">
          <span className="material-symbols-outlined text-primary">smart_toy</span>
          <span className="font-bold">Mostafa.AI</span>
        </div>
        <div className="flex flex-col items-center gap-4 text-sm text-text-sub dark:text-gray-400 sm:flex-row sm:gap-8">
          <a className="hover:text-primary transition-colors" href="#">
            Home
          </a>
          <a className="hover:text-primary transition-colors" href="#work">
            Work
          </a>
          <a className="hover:text-primary transition-colors" href="#skills">
            Services
          </a>
          <a className="hover:text-primary transition-colors" href="#about">
            Contact
          </a>
        </div>
        <p className="text-xs text-gray-400 dark:text-gray-600">
          © 2024 Mostafa.AI. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
