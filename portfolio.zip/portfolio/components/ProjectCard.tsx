"use client";

import Image from "next/image";

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  imageAlt: string;
  onViewCase: () => void;
}

export default function ProjectCard({
  title,
  description,
  tags,
  imageUrl,
  imageAlt,
  onViewCase,
}: ProjectCardProps) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm transition hover:shadow-md dark:bg-surface-dark dark:shadow-none dark:ring-1 dark:ring-gray-800 md:flex-row">
      <div className="relative aspect-video w-full md:h-auto md:w-2/5">
        <Image
          src={imageUrl}
          alt={imageAlt}
          fill
          className="object-cover"
        />
      </div>
      <div className="flex flex-1 flex-col justify-center p-6 md:p-8">
        <div className="mb-2 flex items-center gap-2 flex-wrap">
          {tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-blue-100 px-2 py-0.5 text-xs font-bold text-primary dark:bg-blue-900/40 dark:text-blue-300"
            >
              {tag}
            </span>
          ))}
        </div>
        <h3 className="mb-2 text-xl font-bold text-text-main dark:text-white">
          {title}
        </h3>
        <p className="mb-6 text-text-sub dark:text-gray-400">{description}</p>
        <button
          onClick={onViewCase}
          className="flex w-fit items-center gap-2 text-sm font-bold text-primary hover:text-blue-700"
        >
          View Case Study{" "}
          <span className="material-symbols-outlined text-sm">arrow_outward</span>
        </button>
      </div>
    </div>
  );
}
