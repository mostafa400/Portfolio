"use client";

import { useEffect } from "react";
import Image from "next/image";

interface ProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ProjectModal({ isOpen, onClose }: ProjectModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#0e121b]/60 backdrop-blur-sm p-0 sm:p-6 transition-all duration-300">
      {/* Modal Container */}
      <div className="bg-white dark:bg-[#1a202c] w-full max-w-[1024px] max-h-[90vh] sm:rounded-2xl rounded-t-2xl shadow-modal flex flex-col overflow-hidden relative transform transition-all sm:scale-100">
        {/* Close Button */}
        <div className="absolute top-0 right-0 z-30 p-4">
          <button
            onClick={onClose}
            className="flex items-center justify-center w-10 h-10 rounded-full bg-white/90 dark:bg-black/40 backdrop-blur-sm text-text-main dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors shadow-sm group border border-gray-200 dark:border-gray-600"
          >
            <span className="material-symbols-outlined text-[20px] group-hover:scale-110 transition-transform">
              close
            </span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto modal-scroll flex flex-col h-full bg-white dark:bg-[#1a202c]">
          {/* Hero Section */}
          <div className="relative w-full h-48 sm:h-64 shrink-0">
            <Image
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDloUG0igcwvV1iDM2dMV8sk5Q6HYW-94ilqk6NN-K6e_z4oTa3OpgxJ_JDaSm0US-N5XJsx2cvCvRd_D17YKd5Ymzq6RYcwcmN_OSyPUEVZ9D342GrkP_sd61tU7imeNTxAfzM69i7SsdYo70OgTtVmMYzqHUKgh529yHpGy1WhuUqx0Mw1xGYIqK5PI-UvZeuDaUxX2qGdtt6gHvVEdz8HGcS9IHtTOYBQs5Eu8hHVO4Kykp2_4ts6f3NQQ2ccmIAs1MWB4AX0pM"
              alt="Abstract blue futuristic digital data wave network pattern"
              fill
              className="object-cover"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-[#1a202c] via-white/20 dark:via-[#1a202c]/40 to-transparent"></div>
            {/* Title Overlay */}
            <div className="absolute bottom-0 left-0 w-full px-6 sm:px-10 pb-6 pt-12 bg-gradient-to-t from-white dark:from-[#1a202c] to-transparent">
              <div className="flex flex-col gap-2">
                <p className="text-primary font-bold text-sm tracking-widest uppercase mb-1">
                  AI Automation / Customer Service
                </p>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-text-main dark:text-white leading-tight tracking-tight">
                  WhatsApp Reservation Chatbot
                </h2>
              </div>
            </div>
          </div>

          {/* Content Body */}
          <div className="flex flex-col lg:flex-row gap-10 px-6 sm:px-10 pb-10 pt-2 h-full">
            {/* Main Content Column */}
            <div className="flex-1 flex flex-col gap-8">
              {/* Problem Section */}
              <div className="group/section">
                <div className="flex items-center gap-3 mb-3 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <span className="material-symbols-outlined text-red-500 dark:text-red-400">
                    report_problem
                  </span>
                  <h3 className="text-xl font-bold text-text-main dark:text-white tracking-tight">
                    The Problem
                  </h3>
                </div>
                <p className="text-text-main dark:text-gray-300 text-base sm:text-lg font-normal leading-relaxed">
                  Manual booking took{" "}
                  <span className="font-bold border-b-2 border-red-200 dark:border-red-900/50">
                    15+ minutes per client
                  </span>
                  , creating a bottleneck in operations. This friction led to a 20%
                  drop-off rate and customer frustration due to delayed responses
                  during peak hours.
                </p>
              </div>

              {/* Solution Section */}
              <div className="group/section">
                <div className="flex items-center gap-3 mb-3 border-b border-gray-100 dark:border-gray-800 pb-2">
                  <span className="material-symbols-outlined text-primary dark:text-blue-400">
                    check_circle
                  </span>
                  <h3 className="text-xl font-bold text-text-main dark:text-white tracking-tight">
                    The Solution
                  </h3>
                </div>
                <p className="text-text-main dark:text-gray-300 text-base sm:text-lg font-normal leading-relaxed">
                  Built an automated{" "}
                  <span className="font-bold text-primary">n8n workflow</span>{" "}
                  integrating OpenAI Assistants API. The system interprets natural
                  language queries, checks real-time slot availability, handles edge
                  cases, and updates Google Calendar instantly.
                </p>
              </div>

              {/* CTA */}
              <div className="pt-4 flex flex-wrap gap-4">
                <button className="flex items-center gap-2 bg-primary hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg transition-all shadow-lg hover:shadow-primary/30 active:scale-95">
                  <span>View Live Demo</span>
                  <span className="material-symbols-outlined text-sm">
                    open_in_new
                  </span>
                </button>
                <button className="flex items-center gap-2 bg-transparent border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800 text-text-main dark:text-white font-bold py-3 px-6 rounded-lg transition-all">
                  <span>GitHub Repo</span>
                  <span className="material-symbols-outlined text-sm">code</span>
                </button>
              </div>
            </div>

            {/* Sidebar Column */}
            <div className="w-full lg:w-[340px] shrink-0 flex flex-col gap-8">
              {/* Results Card */}
              <div className="bg-gray-50 dark:bg-gray-800/40 rounded-xl p-6 border border-gray-100 dark:border-gray-700/50">
                <div className="flex items-center gap-2 mb-5 text-text-sub dark:text-gray-400">
                  <span className="material-symbols-outlined text-[20px]">
                    equalizer
                  </span>
                  <h4 className="text-sm font-bold uppercase tracking-wider">
                    Project Results
                  </h4>
                </div>
                <div className="grid grid-cols-1 gap-3">
                  {/* Metrics */}
                  <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex flex-col">
                      <span className="text-3xl font-bold text-text-main dark:text-white leading-none">
                        5 min
                      </span>
                      <span className="text-xs font-medium text-text-sub dark:text-gray-400 mt-1">
                        Avg. Booking Time
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-green-50 dark:bg-green-900/20 flex items-center justify-center text-green-600 dark:text-green-400">
                      <span className="material-symbols-outlined">timer</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex flex-col">
                      <span className="text-3xl font-bold text-text-main dark:text-white leading-none">
                        24/7
                      </span>
                      <span className="text-xs font-medium text-text-sub dark:text-gray-400 mt-1">
                        Availability
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center text-purple-600 dark:text-purple-400">
                      <span className="material-symbols-outlined">schedule</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
                    <div className="flex flex-col">
                      <span className="text-3xl font-bold text-text-main dark:text-white leading-none">
                        +40%
                      </span>
                      <span className="text-xs font-medium text-text-sub dark:text-gray-400 mt-1">
                        Conversion Rate
                      </span>
                    </div>
                    <div className="w-10 h-10 rounded-full bg-primary/10 dark:bg-blue-900/20 flex items-center justify-center text-primary dark:text-blue-400">
                      <span className="material-symbols-outlined">
                        trending_up
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tech Stack */}
              <div>
                <div className="flex items-center gap-2 mb-4 text-text-sub dark:text-gray-400">
                  <span className="material-symbols-outlined text-[20px]">
                    layers
                  </span>
                  <h4 className="text-sm font-bold uppercase tracking-wider">
                    Tech Stack
                  </h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {["n8n", "OpenAI API", "Node.js", "Google Calendar", "PostgreSQL"].map(
                    (tech) => (
                      <span
                        key={tech}
                        className="inline-flex items-center px-3 py-1.5 rounded-lg bg-primary/10 dark:bg-primary/20 text-primary dark:text-blue-300 text-sm font-bold border border-primary/20"
                      >
                        {tech}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
