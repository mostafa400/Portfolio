"use client";

import { useState } from "react";
import ProjectCard from "./ProjectCard";
import ProjectModal from "./ProjectModal";

export default function Projects() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const projects = [
    {
      title: "Chatbot for Real Estate",
      description:
        "Automating lead qualification with natural language processing to engage visitors 24/7 and schedule appointments instantly.",
      tags: ["NLP", "React"],
      imageUrl:
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBJp2kLwwGGYOvhUbkekKH0GRiQ1X4Z5KiluAnUXoCHvdEcpbOy7SG12d26CIaS7BuQKwNOS_WeLllkRx3vdKVzgKq4FOau6EnD_0zpevkU25AWIMEEa3ZqPFpVRm0cPe9wQl4u3tRpD2WpRba41iGoiDC5coltwfv1BqxMed1_JwFx5J2v7lG5eovk-ZVf33F8YQXAbHsMrZDLgkTkHg2o6YbdROqChwSoyDjGy8m2zttfdqxJM-o-4tiBwQZDeYuBJE36PiaEX00",
      imageAlt: "Modern real estate building with blue sky",
    },
    {
      title: "Data Extraction Pipeline",
      description:
        "Scraping and processing invoice data for accounting firms, reducing manual entry errors by 94% using OCR and Regex.",
      tags: ["Data Engineering", "Python"],
      imageUrl:
        "https://lh3.googleusercontent.com/aida-public/AB6AXuDIGhq7fA9qk28vZY7qh815-jEHOWJPoxREVaHBmNED29eYWmE4H0WUkQFNU2LUaqn2W1AZXbOhvow4jb04dPyoUKgx8_g4Dgb-lHcP_1cqvScO_RFTO3RWCvkrjhHUOb3376C3p_dOsQCaBlWw07k-EO0QrUuX6wKnRNDuZ0y3kgLjlOhAZTekQMJNwJfKtc9mPx7ybOO7TzoP_K_QUTd6wY9ghPenx5jzNKWqTgktJ8pvJ_hTkA5MusgFe4RYNtfnxolDsOdOFH4",
      imageAlt: "Data visualization dashboard on a tablet screen",
    },
    {
      title: "CRM Sync Workflow",
      description:
        "Two-way sync system between HubSpot and Salesforce ensuring marketing and sales teams always have up-to-date data.",
      tags: ["Automation", "Zapier"],
      imageUrl:
        "https://lh3.googleusercontent.com/aida-public/AB6AXuACjeYBeHuA9vTNZZ0zyUCehX7GdlWoCKcPWwmJuKbF1iJYnj3JLiNjs3DH_V5_ajk_DlcHOW9SZktqGito1fBhzBGdg4BNYZbhrdJLjp40f0LClDZ4ateFi79SBq-xOmKQ3TvrmRQT2nab4sjI60SQpw90kDfecfeWGwUN7YzKiYetqHYd4Wg32aIvcjnGCFNInSxyUnh3j4HiBxlqjhmUW8c-Ix2CKeh5PSaaV0h1WofCrHq-Ydm4SH-7w2ScmU4fN00_EwaHSsQ",
      imageAlt: "Person holding a smartphone with an automation app interface",
    },
  ];

  return (
    <>
      <section id="work" className="px-6 py-12 lg:px-40">
        <div className="mx-auto flex max-w-[960px] flex-col">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="text-3xl font-bold tracking-tight text-text-main dark:text-white">
              Featured Projects
            </h2>
            <a
              className="hidden items-center text-sm font-bold text-primary hover:underline md:flex"
              href="#"
            >
              View all work{" "}
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </a>
          </div>
          <div className="flex flex-col gap-8">
            {projects.map((project, index) => (
              <ProjectCard
                key={index}
                {...project}
                onViewCase={() => setIsModalOpen(true)}
              />
            ))}
            <div className="flex justify-center pt-4 md:hidden">
              <button className="flex h-12 w-full items-center justify-center rounded-xl border border-gray-200 bg-white px-6 text-base font-bold text-text-main dark:border-gray-700 dark:bg-surface-dark dark:text-white">
                View All Projects
              </button>
            </div>
          </div>
        </div>
      </section>

      <ProjectModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}
