export default function Skills() {
  const skills = [
    "Python",
    "OpenAI API",
    "LangChain",
    "TensorFlow",
    "Zapier",
    "Pinecone",
    "FastAPI",
  ];

  return (
    <section id="skills" className="border-y border-gray-200 bg-white py-8 dark:border-gray-800 dark:bg-surface-dark">
      <div className="mx-auto flex w-full max-w-[960px] flex-col gap-4 px-6 lg:px-40">
        <p className="text-sm font-bold uppercase tracking-wider text-text-sub dark:text-gray-500">
          Tech Stack &amp; Tools
        </p>
        <div className="flex flex-wrap gap-3">
          {skills.map((skill) => (
            <span
              key={skill}
              className="inline-flex items-center rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-text-main dark:bg-gray-800 dark:text-white"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
